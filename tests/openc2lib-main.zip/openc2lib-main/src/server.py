#!../.venv/bin/python3
# Example to use the OpenC2 library
#

import logging
import sys

import openc2lib as oc2

from openc2lib.encoders.json import JSONEncoder
from openc2lib.transfers.http import HTTPTransfer
from openc2lib.actuators.iptables_actuator import IptablesActuator
import openc2lib.profiles.slpf as slpf
from flask import Flask, request, jsonify

#logging.basicConfig(filename='consumer.log',level=logging.DEBUG)
logging.basicConfig(stream=sys.stdout,level=logging.INFO)
logger = logging.getLogger('openc2')

# app = Flask(__name__)

def main():

# Instantiate the list of available actuators, using a dictionary which key
# is the assed_id of the actuator.
	actuators = {}
	actuators[(slpf.nsid,'iptables')]=IptablesActuator()

	c = oc2.Consumer("testconsumer",
                     actuators,
                     JSONEncoder(),
                     HTTPTransfer("127.0.0.1", 8080))


	c.run()

# @app.route('/.well-known/openc2', methods=['POST'])
# def receive_data():
#     data = request.get_data()
#     command = json.loads(data)
#     # Extract headers datas from received command
#     headers = command.get("headers", {})
#     request_id = command.get("headers", {}).get("request_id", "N/A")
#     timestamp = command.get("headers", {}).get("created") or datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
#     print(f"Received OpenC2 Command: {json.dumps(command, indent=4)}")
#
#     # Create an Actuator object with the OpenC2 command
#     action = command.get("body", {}).get("openc2", {}).get("request", {}).get("action")
#     print(f"Here is received action", action)
#     target = command.get("body", {}).get("openc2", {}).get("request", {}).get("target")
#     print(f"Here is received target", target)
#     args = command.get("body", {}).get("openc2", {}).get("request", {}).get("args", {})
#
#     actuator = Actuator(action, target, args)
#     actuator_result = actuator.action_mapping(action, target)
#
#     response = {
#         'headers':headers,
#         "request_id": request_id,
#         "created": timestamp,
#         'result':actuator_result
#     }
#
#     return jsonify(response)


if __name__ == "__main__":
	main()
	# app.run(host='0.0.0.0', port=5000, debug=True)
