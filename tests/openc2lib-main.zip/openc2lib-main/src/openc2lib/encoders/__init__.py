# NOTE: This file is only provided for including all subfolders in the documentation.

""" OpenC2 Encoding formats

	This folder collects the implementation of Encoding formats provided with openc2lib.
"""
