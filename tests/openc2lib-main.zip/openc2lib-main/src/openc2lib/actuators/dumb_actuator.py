""" Dumb `Actuator`

	This module provides a dumb actuator that always answer with a fixed 
	message. Use it for testing only.
"""
from openc2lib import ArrayOf,ActionTargets, TargetEnum, Nsid, Version,Results, StatusCode, StatusCodeDescription, Actions, Command, Response

# A dumb actuator that does not implement any function but can
# be used to test the openc2 communication.
class DumbActuator:
	def run(self, cmd):

		at = ActionTargets()
		at[Actions.scan] = [TargetEnum.ipv4_net]
		at[Actions.query] = [TargetEnum.ipv4_net, TargetEnum.ipv4_connection]
		pf = ArrayOf(Nsid)()
		pf.append(Nsid('slpf'))
		res = Results(versions=Version(1,0), profiles=pf, pairs=at,rate_limit=3)
		r = Response({'status': StatusCode.OK, 'status_code': StatusCodeDescription[StatusCode.OK], 'results': res})

		return r

	@staticmethod
	def insert_rule(cmd, iptables_target):
		target = cmd.get('target', [])
		args = cmd.get('args', [])
		iptables_target = args.get('iptables_target')
		supported_targets = ['ipv4_connection', 'ipv6_connection', 'ipv4_net', 'ipv6_net']
		cmd = None
		base_cmd = "iptables -A INPUT"

		for target_key in supported_targets:
			if target_key in target:
				if target_key in ['ipv4_connection', 'ipv6_connection']:
					connection = target[target_key]
					src_ip = connection.get('src_addr')
					dst_ip = connection.get('dst_addr')
					src_port = connection.get('src_port')
					dst_port = connection.get('dst_port')
					protocol = connection.get('protocol')
					cmd = f"{base_cmd} -p {protocol}"
					if src_ip:
						cmd += f" -s {src_ip}"
					if dst_ip:
						cmd += f" -d {dst_ip}"
					if src_port:
						cmd += f" --sport {src_port}"
					if dst_port:
						cmd += f" --dport {dst_port}"
					cmd += f" -j {iptables_target}"

				elif target_key in ['ipv4_net', 'ipv6_net']:
					net = target[target_key]
					ip = net.get('network_address')
					cidr = net.get('netmask', '')
					cmd = f"{base_cmd} -s {ip}"
					if cidr:
						cmd += f"/{cidr}"
					cmd += f" -j {iptables_target}"

		if cmd:
			result = IptablesManager.run_iptables_command([cmd])
			result[0]['command'] = cmd
			return result[0]

		return {"status": "error", "message": "Option not supported"}

	@staticmethod
	def delete_rule(db_result, additional_cmds):
		if db_result:
			cmd_parts = db_result[0].split()
			if len(cmd_parts) > 1 and cmd_parts[1].startswith('-'):
				cmd_parts[1] = '-D'
				cmd = ' '.join(cmd_parts)
				return IptablesManager.run_iptables_command(cmd)
		return [{"status": "error", "message": "Option not supported"}]

	def modify_command_for_deletion(cmd):
		cmd_parts = cmd.split()
		# Remove the number after "INPUT", it's aims to update iptables command
		if "INPUT" in cmd_parts:
			input_index = cmd_parts.index("INPUT")
			if input_index + 1 < len(cmd_parts) and cmd_parts[input_index + 1].isdigit():
				del cmd_parts[input_index + 1]
		for i, part in enumerate(cmd_parts):
			if part.startswith('-') and not part.startswith('-D'):
				cmd_parts[i] = '-D'
				break
		modified_cmd = ' '.join(cmd_parts)
		return modified_cmd


