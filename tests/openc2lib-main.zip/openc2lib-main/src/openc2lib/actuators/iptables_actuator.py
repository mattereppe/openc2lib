""" Skeleton `Actuator` for SLPF profile

	This module provides an example to create an `Actuator` for the SLPF profile.
	It only answers to the request for available features.
"""
from openc2lib import ArrayOf, ActionTargets, TargetEnum, Nsid, Version,Actions, Command, Response, StatusCode, StatusCodeDescription
import subprocess
import openc2lib.profiles.slpf as slpf
from openc2lib.actuators.SQLDatabase import SQLDatabase
from openc2lib.actuators.dumb_actuator import DumbActuator


OPENC2VERS=Version(1,0)
""" Supported OpenC2 Version """

# An implementation of the slpf profile. 
class IptablesActuator:
	""" Dumb SLPF implementation

		This class provides a skeleton for implementing an `Actuator` according to the openc2lib approach.
	"""
	profile = slpf

	def run(self, cmd):

		if not slpf.validate_command(cmd):
			return Response(status=StatusCode.NOTIMPLEMENTED, status_text='Invalid Action/Target pair')
		if not slpf.validate_args(cmd):
			return Response(status=StatusCode.NOTIMPLEMENTED, status_text='Option not supported')

		match cmd.action:
			case Actions.query:
				result = self.query(cmd)
			case Action.allow:
				result = self.allow(cmd)
			case Action.deny:
				result = self.deny(cmd)

		return result

	def query(self, cmd):
		""" Query action

            This method implements the `query` action.
            :param cmd: The `Command` including `Target` and optional `Args`.
            :return: A `Response` including the result of the query and appropriate status code and messages.
        """

		feat = {}
		for f in cmd.target.getObj():
			match f:
				case Feature.versions:
					feat[versions]=ArrayOf(Version)([OPENC2VERS])
				case Feature.profiles:
					pf = ArrayOf(Nsid)()
					pf.append(Nsid('slpf'))
					feat[profiles]=pf
				case Features.pairs:
					feat[pairs]=slpf.AllowedCommandTarget
				case Features.rate_limit:
					feat[rate_limit]=1

		res = slpf.Results(feat)
		r = Response(status=StatusCode.OK, status_text=StatusCodeDescription[StatusCode.OK], results=res)
					


#		features_info = {
#
#			"versions": ["1.0"],
#			"profiles": ["SLPF", "iot-front-door-lock"],
#			"pairs": {
#				"allow": ["ipv4_net", "ipv6_net", "ipv4_connection", "ipv6_connection"],
#				"deny": ["ipv4_net", "ipv6_net", "ipv4_connection", "ipv6_connection"],
#				"query": ["features"],
#				"delete": ["slpf:rule_number"],
#				"update": ["file"]
#			},
#			"rate_limit": 100
#		}
#		# Respond contents based on the requested features
#		requested_features = cmd.get('features', [])
#		query_response = {feature: features_info.get(feature) for feature in requested_features}
#		return {"status": "success", "result": query_response}

	def insert_handler(self, target, action, rule_number=None):
		result = IptablesManager.insert_rule(target, action)
		self.db.insert_command(result.get('command'), rule_number)

	def allow(self, cmd):
		target = cmd.target.getObj()
		args = cmd.args
		return self.insert_handler(target, args, "ACCEPT")

	def deny(self, cmd):
		target = cmd.target.getObj()
		args = cmd.args
		return self.insert_handler(target, args, "DROP")

	def update(self, cmd):
		target = cmd.target.getObj()
		args = cmd.args
		rule_number = int(cmd.target.getObj())
		delete_result = self.delete_handler(target, args, rule_number)
#iptables_target = args.get('iptables_target')
		return self.insert_handler(target, args, iptables_target, rule_number)

	def delete(self, cmd):
		target = cmd.get('target', {})
		args = cmd.get('args', {})



		if 'slpf:rule_number' in target:
			rule_number = target['slpf:rule_number']
			cmd_data = self.db.get_command_from_rule_number(rule_number)
			if cmd_data:
				modified_cmd = IptablesManager.modify_command_for_deletion(cmd_data[0])
				result = IptablesManager.run_iptables_command(modified_cmd)
				self.db.delete_command_by_rule_number(rule_number)
				return result
		return {"status": "error", "message": "Command not found"}

	def __notimplemented(self, cmd):
		""" Default response

			Default response returned in case an `Action` is not implemented.
			The `cmd` argument is only present for uniformity with the other handlers.
			:param cmd: The `Command` that triggered the error.
			:return: A `Response` with the appropriate error code.

		"""
		return Response(status=StatusCode.NOTIMPLEMENTED, status_text='Command not implemented')
