# Logging for openc2lib

TODO
